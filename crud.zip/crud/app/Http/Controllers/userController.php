<?php

namespace App\Http\Controllers;
use App\Models\userModel;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Models\chat;
use Illuminate\Support\Facades\DB;


class userController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create(Request $request)
    {
$input = $request->all();
$validator = Validator::make($input, [
'name' => 'required',
'phone' => 'required',
'email' => 'required',
]);
if($validator->fails()){
return $this->sendError('Validation Error.', $validator->errors());       
}
$users = userModel::create($input);
return response()->json([
"success" => true,
"message" => "Product created successfully.",
"data" => $users
]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $user = userModel::find($id);
        if (is_null($user)) {
        return $this->sendError('user not found.');
        }
        return response()->json([
        "success" => true,
        "message" => "User retrieved successfully.",
        "data" => $user
        ]);
    }

    public function showuser()
    {
        $user = userModel::all();
        if (is_null($user)) {
        return $this->sendError('user not found.');
        }
        return response()->json([
        "success" => true,
        "message" => "User retrieved successfully.",
        "data" => $user
        ]);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request,$id)
    {
        $updateData = $request->validate([
            'name' => 'required|max:255',
            'email' => 'required|max:255',
            'phone' => 'required|numeric',
            
        ]);
       $update = userModel::whereId($id)->update($updateData);
       if($update){
        return response()->json([
            "success" => true,
            "message" => "User updated successfully."
            ]);
        }else{
            return response()->json([
                "success" => false,
                "message" => "User updated not successfully."
                ]);
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(userModel  $user)
    {
        $user->delete();
        return response()->json([
        "success" => true,
        "message" => "user deleted successfully.",
        "data" => $user
        ]);
    }


    //add message 
public function createmesage(Request $request)
    {
$input = $request->all();
$validator = Validator::make($input, [
'sender_id' => 'required',
'reciever_id' => 'required',
'message' => 'required',
'status' => '0'
]);
if($validator->fails()){
return $this->sendError('Validation Error.', $validator->errors());       
}
$users = chat::create($input);
return response()->json([
"success" => true,
"message" => "message  send successfully.",
"data" => $users
]);
    }

    public function deletemessage(chat  $chat)
    {
        $chat->delete();
        return response()->json([
        "success" => true,
        "message" => "message deleted successfully.",
        "data" => $chat
        ]);
    }

    public function showMessage($id)
    {
        $user = DB::table('chats')->select('reciever_id','message')->where('reciever_id', $id)->get();
        if (is_null($user)) {
        return $this->sendError('user not found.');
        }
        return response()->json([
        "success" => true,
        "message" => "User retrieved successfully.",
        "data" => $user
        ]);
    }
}
