<?php

namespace Database\Seeders;

use App\Models\chat;

use Illuminate\Database\Seeder;

 class chats extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
         chat::create([
            'sender_id' => '1',
            'reciever_id' => '2',
            'message' => 'Hey himanshu',
            'status' => '0',

        ]);
    }

}
