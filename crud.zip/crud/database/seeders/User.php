<?php

namespace Database\Seeders;
use App\Models\userModel;

use Illuminate\Database\Seeder;

class User extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        userModel::create([
            'name' => 'himanshu bakshi',
            'phone' => '7988',
            'email' => 'himanshubakshi10@gmail.com',
            'photo' => 'img.jpg',

        ]);
    }
}

